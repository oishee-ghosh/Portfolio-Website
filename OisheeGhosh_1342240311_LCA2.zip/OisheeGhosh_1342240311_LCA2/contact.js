// Fade-in IntersectionObserver
const fadeEls = document.querySelectorAll('.fade-in');
const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('visible');
    }
  });
}, { threshold: 0.1 });
fadeEls.forEach(el => observer.observe(el));

// Form validation
const form = document.querySelector('.contact-form');
const inputs = form.querySelectorAll('input, textarea');

form.addEventListener('submit', (e) => {
  e.preventDefault();
  let hasError = false;

  inputs.forEach(input => {
    if (!input.value.trim()) {
      input.classList.add('error');
      hasError = true;
    } else {
      input.classList.remove('error');
    }
  });

  if (hasError) {
    alert("Please fill in all fields before submitting.");
  } else {
    alert("Thank you! Your message has been sent.");
    form.reset();
  }
});