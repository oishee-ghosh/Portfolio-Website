let allparas = document.getElementsByTagName("p");
console.log("This is my HTML Collection of all <p> tags .-.");
console.log(allparas);
function changingparastyles()
{
    allparas[0].style.fontsize="24px";
    allparas[3].style.color="rgb(255,255,255)";
}