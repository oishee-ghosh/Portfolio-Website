let allparas = document.getElementsByTagName("p");
console.log("This is my HTML Collection of all <p> tags .-.");
console.log(allparas);
function changingparastyles()
{
    allparas[0].style.fontsize="24px";
    allparas[3].style.color="rgb(255,255,255)";
}

console.log("This is my HTML Collection of all tags that have the class name picniclist - ")
console.log(picklist);
function changingListStyles()
{
    picklist[1].style.color="yellow";
    picklist[3].style.backgroundColor="B7CFC00";
}

for(let uLItem of picklist)
{
    uLItem.style.fontStyle="italic";
}